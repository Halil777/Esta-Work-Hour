import { useRef, useState } from 'react'
import { AlertCircle, Upload } from 'lucide-react'
import { workersApi } from '../../api/workers'
import { useTranslation } from '../../i18n/useTranslation'
import { AppModal } from '../ui/AppModal'

type WorkerCardImportModalProps = {
  onClose: () => void
}

export function WorkerCardImportModal({ onClose }: WorkerCardImportModalProps) {
  const { t } = useTranslation()
  const fileRef = useRef<HTMLInputElement>(null)
  const [file, setFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{ linked: number; notFound: number } | null>(null)
  const [error, setError] = useState('')

  const handleUpload = async () => {
    if (!file) return
    setLoading(true)
    setError('')
    try {
      const response = await workersApi.importCards(file)
      setResult(response)
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Upload failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <AppModal
      title={t.cardImport.title}
      onClose={onClose}
      maxWidth={440}
      footer={
        <>
          <button className="btn btn--secondary btn--sm" type="button" onClick={onClose}>{result ? t.common.close : t.common.cancel}</button>
          {!result && (
            <button className="btn btn--primary btn--sm" type="button" onClick={handleUpload} disabled={!file || loading}>
              {loading ? t.common.uploading : <><Upload size={13} /> {t.common.import}</>}
            </button>
          )}
        </>
      }
    >
      {!result ? (
        <>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 8 }}>
            "card numbers.xlsx" - <code>{'Табельный номер -> Карта №'}</code>
          </p>
          {error && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px', background: 'var(--danger-light)', borderRadius: 6, marginBottom: 10, color: 'var(--danger)', fontSize: 13 }}>
              <AlertCircle size={14} /> {error}
            </div>
          )}
          <input ref={fileRef} type="file" accept=".xlsx,.xls" style={{ display: 'none' }} onChange={event => setFile(event.target.files?.[0] ?? null)} />
          <div onClick={() => fileRef.current?.click()} style={{ border: '2px dashed var(--border)', borderRadius: 8, padding: '24px 16px', textAlign: 'center', cursor: 'pointer', color: 'var(--text-muted)', fontSize: 13, background: file ? 'var(--success-light)' : undefined }}>
            {file ? <span style={{ color: 'var(--success)' }}>{file.name}</span> : <span><Upload size={20} style={{ display: 'block', margin: '0 auto 6px' }} />{t.cardImport.chooseFile}</span>}
          </div>
        </>
      ) : (
        <div style={{ padding: '8px 0' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 12px', background: 'var(--success-light)', borderRadius: 6 }}>
              <span style={{ fontSize: 13 }}>{t.cardImport.cardLinked}</span>
              <strong style={{ color: 'var(--success)' }}>{result.linked}</strong>
            </div>
            {result.notFound > 0 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 12px', background: 'var(--warning-light, #FFF7ED)', borderRadius: 6 }}>
                <span style={{ fontSize: 13 }}>{t.cardImport.notFound}</span>
                <strong style={{ color: 'var(--warning, #F59E0B)' }}>{result.notFound}</strong>
              </div>
            )}
          </div>
        </div>
      )}
    </AppModal>
  )
}
